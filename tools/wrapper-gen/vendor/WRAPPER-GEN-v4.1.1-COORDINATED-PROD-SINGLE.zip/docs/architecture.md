# Architecture

Axum-based HTTP service with domain/service separation.
