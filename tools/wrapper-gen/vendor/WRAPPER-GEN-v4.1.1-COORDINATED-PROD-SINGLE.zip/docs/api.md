# API

`POST /v1/run` — execute domain manifest.
