# ADR-001 Use TDLN

Adopt TDLN policies and receipt model.
