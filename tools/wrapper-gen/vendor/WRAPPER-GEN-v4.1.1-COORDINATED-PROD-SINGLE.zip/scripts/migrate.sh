#!/usr/bin/env bash
set -euo pipefail
echo 'no-op'
