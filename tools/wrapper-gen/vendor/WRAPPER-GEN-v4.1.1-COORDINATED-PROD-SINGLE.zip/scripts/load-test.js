console.log('TODO: k6/locust adapter');
