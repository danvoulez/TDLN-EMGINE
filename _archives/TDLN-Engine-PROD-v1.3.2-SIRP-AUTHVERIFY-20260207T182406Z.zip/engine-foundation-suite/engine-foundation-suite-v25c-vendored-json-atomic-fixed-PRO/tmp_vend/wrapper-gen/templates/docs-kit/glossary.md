# Glossary (short)

- JSON✯Atomic: canonical JSON + content addressing (CID).
- Receipt: machine-verifiable decision (ACK/ASK/NACK) + proofs.
- PoI: Proof-of-Indecision — explains missing evidence instead of crashing.
- Presign: short-lived URL for data access after RBAC.
