# Changelog
All notable changes to **{WRAPPER_NAME}** will be documented in this file.
Format: Keep a Changelog • SemVer

## [Unreleased]
### Added
- Initial docs spine (Product Spine, ADRs, Architecture, Runbook).

## [0.1.0] - 2026-02-05
### Added
- Generated wrapper (preset: {PRESET}, flavors: {FLAVORS}, color: {THEME_COLOR}).
- OpenAPI template, Dockerfile, .env.example, Makefile, CI.
- /metrics endpoint.
