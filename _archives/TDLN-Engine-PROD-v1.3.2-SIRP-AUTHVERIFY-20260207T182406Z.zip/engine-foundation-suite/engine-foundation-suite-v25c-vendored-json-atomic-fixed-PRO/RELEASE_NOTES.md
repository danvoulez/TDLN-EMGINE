# Release 25.0.1 — Professional Integration

- Integrated fixed unit + example + tools into canonical paths.
- Added manifest, checksums, provenance, SBOM at top-level.
