
# Demo Keys (for local testing only)

- Secret (base64): 1y281hlr+F0VYIGRtsCv8e4WsRd7y1JArrZME9/obq8=
- Verifying key: derive with `ed25519_dalek::VerifyingKey::from(&SigningKey::from_bytes(...))` and export base64.
