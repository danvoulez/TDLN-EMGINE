
use regex::Regex;
use tdln_receipt::Card;

#[derive(Debug)]
pub enum Verdict {
    Pass,
    Warn(&'static str),
    Fail(&'static str),
}

pub fn verify_rref_11(card: &Card) -> Verdict {
    // Basic fields
    if card.kind != "receipt.card.v1" { return Verdict::Fail("BAD_KIND"); }
    if card.realm != "trust" { return Verdict::Fail("BAD_REALM"); }
    match card.decision.as_str() {
        "ACK" | "ASK" | "NACK" | "RUNNING" => {},
        _ => return Verdict::Fail("BAD_DECISION"),
    }
    let re_handle = Regex::new(r"^https://cert\.tdln\.foundry/r/b3:[0-9a-f]{16,}$").unwrap();
    if !re_handle.is_match(&card.links.card_url) { return Verdict::Fail("BAD_LINK"); }

    // proof fields
    if card.proof.seal.alg != "ed25519-blake3" { return Verdict::Fail("BAD_SEAL"); }
    if card.proof.seal.kid.is_empty() || card.proof.seal.sig.is_empty() { return Verdict::Fail("BAD_SEAL"); }

    let re_cid = Regex::new(r"^cid:b3:[0-9a-f]{16,}$").unwrap();
    if !re_cid.is_match(&card.output_cid) { return Verdict::Fail("BAD_OUTPUT_CID"); }
    if card.proof.hash_chain.is_empty() { return Verdict::Fail("HASH_CHAIN_EMPTY"); }
    let has_output = card.proof.hash_chain.iter().any(|s| s.kind=="output" && s.cid==card.output_cid);
    if !has_output { return Verdict::Fail("HASH_CHAIN_INCOMPLETE"); }

    if card.decision=="ASK" || card.decision=="NACK" {
        if card.poi.as_ref().and_then(|p| p.get("present")).and_then(|v| v.as_bool()) != Some(true) {
            return Verdict::Fail("POI_MISSING"); }
    }

    // refs policy
    let re_canon = Regex::new(r"^https://registry\.tdln\.foundry/v1/objects/").unwrap();
    let re_tdln  = Regex::new(r"^tdln://objects/").unwrap();
    let mut warned = None;
    for r in &card.refs {
        if !re_cid.is_match(&r.cid) { return Verdict::Fail("REF_MISSING_CID"); }
        if r.hrefs.is_empty() { return Verdict::Fail("REF_NO_HREFS"); }
        let is_private = r.private.unwrap_or(false) || r.kind.to_lowercase().contains("private");
        let portable = r.hrefs.iter().any(|h| re_canon.is_match(h) || re_tdln.is_match(h));
        if is_private && !portable {
            warned.get_or_insert("PRIVATE_NO_PORTABLE"); }
        if !is_private && !portable {
            warned.get_or_insert("PUBLIC_NO_CANONICAL_OR_TDLN"); }
    }
    if let Some(code) = warned { Verdict::Warn(code) } else { Verdict::Pass }
}
